HyperCities
===========

A collaborative research and educational platform for traveling back in time to explore the historical layers of city spaces in a collaborative, hypermedia environment.

For more about HyperCities, see [the main site](http://hypercities.com).
