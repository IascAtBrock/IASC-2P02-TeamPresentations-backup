<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="css/regForm.css" />
<title>:: Hypercities :: </title>
</head>

<body>
<div id="regWrapper">
	<h1>Thank you for registering</h1>
	A confirmation email has been sent to you.  Please follow the link in that
	email to complete your registration.
	<br><br>
</div>
</body>
